# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

from django.contrib.auth.models import User
# Create your models.

vehicle_type_choice=(
	('vehicle_type' ,'Vehicle type'),
	('car' ,'Car'),
	('jeep', 'Jeep'),
	('two wheeler', 'Two wheeler'),
	('three wheeler' ,'Three wheeler'),
	('transport vehicle-goods' ,'transport vehicle-goods'),
	('transport vehicle-people', 'transport vehicle-people'),
)

vehicle_make_choice=(
	('vehicle make' ,'Vehicle make'),
	('hyundai' ,'Hyundai'),
	('tata', 'Tata'),
	('mahindra', 'Mahindra'),
	('Maruti' ,'Maruti'),
	('Toyota' ,'Toyota'),
	('Honda', 'Honda'),
	('Bajaj', 'Bajaj'),
	('Royal Enfield', 'Royal Enfield'),
	('Nissan', 'Nissan'),
	('Ashok Leyland', 'Ashok Leyland'),
)

vehicle_manufacture_year_choice=(
	('vehicle manufacture year' ,'Vehicle manufacture year'),
	('1995' ,'1995'),
	('1996' ,'1996'),
	('1998' ,'1997'),
	('1999' ,'1999'),
	('2000' ,'2000'),
	('2001' ,'2001'),
	('2002' ,'2002'),
	('2003' ,'2003'),
	('2004' ,'2004'),
	('2005' ,'2005'),
	('2006' ,'2006'),
	('2007' ,'2007'),
	('2008' ,'2008'),
	('2009' ,'2009'),
	('2010' ,'2010'),
	('2011' ,'2011'),
	('2012' ,'2012'),
	('2013' ,'2013'),
	('2014' ,'2014'),
	('2015' ,'2015'),
	('2016' ,'2016'),
	('2017' ,'2017'),
	('2018' ,'2018'),
	('2019' ,'2019'),
	
)

'''class User_table(models.Model):
	Name=models.CharField(max_length=255)
	Username=models.CharField(max_length=255)
	Password=models.CharField(max_length=255)
	Confirm_password=models.CharField(max_length=255)
	Email=models.EmailField(max_length=255)
	Phone=models.IntegerField(null=True)
	Vehicle_type=models.CharField(max_length=255,choices=vehicle_type_choice, default='vehicle_type')
	Vehicle_make=models.CharField(max_length=255,choices=vehicle_make_choice, default='vehicle_make')
	Vehicle_manufacture_year=models.CharField(max_length=255,choices=vehicle_manufacture_year_choice,default='vehicle_manufacture_year')
	class Meta:
		ordering=['Name']
		verbose_name="User_table"
	def __str__(self):
		return self.Name'''

class Customer(models.Model):
	user_data = models.OneToOneField(User)
	Name=models.CharField(max_length=255)
	Phone=models.IntegerField(null=True)
	Vehicle_type=models.CharField(max_length=255,choices=vehicle_type_choice, default='vehicle_type')
	Vehicle_make=models.CharField(max_length=255,choices=vehicle_make_choice, default='vehicle_make')
	Vehicle_manufacture_year=models.CharField(max_length=255,choices=vehicle_manufacture_year_choice,default='vehicle_manufacture_year')
	 
	def __str__(self):
		return self.Name





class Feedback_table(models.Model):
	Name=models.CharField(max_length=255)
	Phone=models.IntegerField(null=True)
	Email=models.EmailField(max_length=255)
	Feedback=models.CharField(max_length=255)
	class Meta:
		ordering=['Name']
		verbose_name="Feedback_table"
	def __str__(self):
		return self.Name


class Service_type_table(models.Model):
	Name=models.CharField(max_length=255)

	def __str__(self):
		return self.Name
	


State_choice=(
	('Select Your State' ,'Select Your State'),
	('Kerala' ,'Kerala'),
)


District_choice=(
	('Select Your District' ,'Select Your District'),
	('Trivandrum' ,'Trivandrum'),
	('Kollam' ,'Kollam'),
	('Pathanamthitta' ,'Pathanamthitta'),
	('Alappuzha' ,'Alappuzha'),
	('Kottayam' ,'Kottayam'),
	('Idukki' ,'Idukki'),
	('Ernakulam' ,'Ernakulam'),
	('Thrissur' ,'Thrissur'),
	('Palakkad' ,'Palakkad'),
	('Malappuram' ,'Malappuram'),
	('Calicut' ,'Calicut'),
	('Wayanad' ,'Wayanad'),
	('Kannur' ,'Kannur'),
	('Kasargod' ,'Kasargod'),
)



class Services_table(models.Model):
	Service_type=models.ForeignKey(Service_type_table, on_delete=models.SET_NULL, null=True)
	Name=models.CharField(max_length=255)
	Phone=models.IntegerField(null=True)
	Email=models.EmailField(max_length=255)
	City=models.CharField(max_length=255)
	District=models.CharField(max_length=255, choices=District_choice, default='Select Your District')
	State=models.CharField(max_length=255, choices=State_choice, default='Kerala')
	class Meta:
		ordering=['Name']
		verbose_name="Services_table"
	def __str__(self):
		return self.Name


class Help_table(models.Model):
	Name=models.CharField(max_length=255)
	Phone=models.IntegerField(null=True)
	Email=models.EmailField(max_length=255)
	Place=models.CharField(max_length=255)
	Text_field=models.CharField(max_length=255)
	class Meta:
		ordering=['Name']
		verbose_name="Help_table"
	def __str__(self):
		return self.Name