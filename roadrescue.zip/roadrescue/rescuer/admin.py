# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from rescuer.models import Customer,Feedback_table,Service_type_table,Services_table,Help_table

admin.site.register(Customer)

admin.site.register(Feedback_table)

admin.site.register(Service_type_table)

admin.site.register(Services_table)

admin.site.register(Help_table)

# Register your models here.
