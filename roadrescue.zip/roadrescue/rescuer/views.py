# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect

from django.views.generic import TemplateView,FormView

from rescuer.forms import Customer,FeedbackForm

from django.contrib.auth.models import User

import urllib
import urllib2
import json

from django.http import HttpResponseRedirect

from django.conf import settings
from django.contrib import messages


from rescuer.forms import UserForm, CustomerForm
from rescuer.models import Customer,Services_table, Service_type_table,Help_table

from django.contrib.auth.decorators import login_required


#from rescuer.models import Comment
#from rescuer.forms import CommentForm


# Create your views here.

class Homeview(TemplateView):
	template_name="home.html"

def Aboutview(request):
	return render(request,'about.html')

def Servicesview(request):
	if request.user.is_staff:
		services_var = Service_type_table.objects.all()
		services_place = Services_table.objects.all()
		context = {
			'services':services_var, 'places':services_place,
		}
		return render(request,'services.html', context)
	else:
		return redirect('/signin')

def Feedbackview(request):
	if request.user.is_staff:

		if request.method == 'POST':
			form = FeedbackForm(request.POST)
			if form.is_valid():
				form.save()
				return redirect('feedback')
		else:
			form = FeedbackForm()
  
		return render(request,'feedback.html',{'form':form})


class RegisterView(FormView):
	template_name = 'register.html'
	form_class = UserForm
	model = User

	def get(self,request,*args,**kwargs):
		self.object = None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		cust_form = CustomerForm()
		return self.render_to_response(self.get_context_data(form1=user_form,form2=cust_form))

	def post(self,request,*args,**kwargs):
		self.object = None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		cust_form = CustomerForm(self.request.POST, self.request.FILES)
		if (user_form.is_valid() and cust_form.is_valid()):
			return self.form_valid(user_form, cust_form)
		else:
			return self.form_invalid(user_form, cust_form)

	def get_success_url(self, **kwargs):
		return ('success')

	def form_valid(self, user_form, cust_form):
		self.object = user_form.save()
		self.object.is_staff=True
		self.object.save()
		cust_obj = cust_form.save(commit=False)
		cust_obj.user_data = self.object
		cust_obj.save()
		return redirect('/signin')

	def form_invalid(self, user_form, cust_form):
		return self.render_to_response(self.get_context_data(form1=user_form,form2=cust_form))


def Rescueview(request):
	if request.user.is_staff:   
		if request.method == 'POST':
			place=request.POST.get('place')
			print(place)
			service_type=request.POST.get('service_type')
			print(service_type)
			service=Services_table.objects.filter(City=place,Service_type__Name=service_type)
			context={
					'services':service
			}
			return render(request, 'rescue.html', context=context)
		else:
			return render(request, 'services.html')
	else:
		return redirect('/signin')


def comments(request):
    comments_list = Comment.objects.order_by('-created_at')

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():

            ''' Begin reCAPTCHA validation '''
            recaptcha_response = request.POST.get('g-recaptcha-response')
            url = 'https://www.google.com/recaptcha/api/siteverify'
            values = {
                'secret': settings.GOOGLE_RECAPTCHA_SECRET_KEY,
                'response': recaptcha_response
            }
            data = urllib.urlencode(values)
            req = urllib2.Request(url, data)
            response = urllib2.urlopen(req)
            result = json.load(response)
            ''' End reCAPTCHA validation '''

            if result['success']:
                form.save()
                messages.success(request, 'New comment added with success!')
            else:
                messages.error(request, 'Invalid reCAPTCHA. Please try again.')

            return redirect('comments')
    else:
        form = CommentForm()

    return render(request, 'signin.html', {'comments': comments_list, 'form': form})




def Helpview(request):
	   
	if request.method == 'POST':
		Name=request.POST.get('full-name')
		Phone=request.POST.get('phone-number')
		Email=request.POST.get('email')
		Place=request.POST.get('place')
		Text_field=request.POST.get('text-field')

		help=Help_table.objects.create(Name=Name,Phone=Phone,Email=Email,Place=Place,Text_field=Text_field)
		return HttpResponseRedirect('/home/')
	else:
		return render(request, 'home.html')