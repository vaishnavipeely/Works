from django.conf.urls import url,include
from rescuer.views import Homeview,RegisterView
from rescuer import views


from django.contrib import admin


from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

urlpatterns=[
			url(r'home',Homeview.as_view(),name="home"),
			url(r'register',RegisterView.as_view(),name="register"),
			url(r'about',views.Aboutview,name="about"),
			url(r'services',views.Servicesview,name="services"),
			url(r'feedback',views.Feedbackview,name="feedback"),
			url(r'^signin$', auth_views.login, {'template_name': 'signin.html'}, name='signin'),
			url(r'^logout/$', auth_views.logout, name='logout'),
			url(r'^rescue$',views.Rescueview,name="rescue"),
			url(r'^oauth/', include('social_django.urls', namespace='social')),
			url(r'help',views.Helpview,name="help"),
    		#url(r'^admin/', admin.site.urls),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns +=  static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)