from django import forms

from rescuer.models import Customer,Feedback_table


from django.contrib.auth.models import User

from django.contrib.auth.forms import UserCreationForm


class UserForm(UserCreationForm):
     class Meta:
         model = User
         fields = ['username','email','password1','password2']

class CustomerForm(forms.ModelForm):
     class Meta:
         model = Customer
         fields=['Name','Phone','Vehicle_type','Vehicle_make','Vehicle_manufacture_year']


class FeedbackForm(forms.ModelForm):
	class Meta:
		model=Feedback_table
		fields=['Name','Phone','Email','Feedback']



