# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Hotel(models.Model):
	hotelname = models.CharField(max_length=20)
	ph_no = models.IntegerField()
	star_rating = models.IntegerField()
	def __str__(self):
		return self.hotelname

status_choices = (
    ('availiable','AVAILIABLE'),
    ('unavailiable', 'UNAVAILIABLE'),
		)		

class Room(models.Model):
	room_name = models.CharField(max_length=50)
	hotel_id = models.ForeignKey(Hotel)
	room_rent = models.IntegerField()
	status = models.CharField(max_length=20, choices=status_choices, default='availiable')	
	def __str__(self):
		return self.room_name

status_choices = (
    ('availiable','AVAILIABLE'),
    ('	unavailiable', 'UNAVAILIABLE'),
		)

class Cab(models.Model):
	cab_number = models.IntegerField()
	cab_seat = models.CharField(max_length=50)
	cab_rent = models.IntegerField()
	status = models.CharField(max_length=20, choices=status_choices, default='availiable')	
	def __int__(self):
		return self.cab_number

class Register(models.Model):
	user_data = models.OneToOneField(User)
	pic = models.ImageField(upload_to = 'media/user/profile_pic')
	dob = models.DateField()
	ph_no = models.IntegerField()
	def __str__(self):
		return self.user_data.username
	
class Bookings(models.Model):
	room_id = models.IntegerField()
	booked_by = models.IntegerField()
	booked_date = models.DateTimeField(auto_now=True)
	start_date = models.DateField()
	end_date = models.DateField()	

class CabBookings(models.Model):
	cab_number = models.IntegerField()
	booked_by = models.IntegerField()
	booked_date = models.DateTimeField(auto_now=True)
	start_from = models.CharField(max_length=50)
	end_to = models.CharField(max_length=50)	
	
