# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from safari.models import Hotel, Room, Cab, Bookings, Register ,CabBookings

# Register your models here.

admin.site.register(Hotel)
admin.site.register(Room)
admin.site.register(Cab)
admin.site.register(Bookings)
admin.site.register(Register)
admin.site.register(CabBookings)
