# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from django.views.generic import TemplateView,ListView,CreateView,FormView, View
from safari.forms import HotelForm,UserForm,RoomCreateForm,CabCreateForm,RegisterForm,BookingForm,CabBookingForm
from safari.models import Hotel,Room,Cab, Bookings,CabBookings
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
import urllib
import urllib2
import json
from django.conf import settings
from django.contrib import messages

# Basic Views
class HomeView(TemplateView):
	template_name='home.html'

class ContactView(TemplateView):
	template_name='contact.html'

class AboutView(TemplateView):
	template_name='about.html'

#views regarding users
class CustomerList(ListView):
	template_name="list.html"
	model = User
	
	def get(self,request):
		if request.user.is_superuser:
			return super(CustomerList, self).get(self,request)

class SignUpView(FormView):
	template_name = 'signup.html'
	form_class = UserForm

	def get(self,request,*args,**kwargs):
		self.object = None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		cust_form = RegisterForm()
		return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form))

	def post(self,request,*args,**kwargs):
		self.object = None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		cust_form = RegisterForm(self.request.POST, self.request.FILES)
		if(user_form.is_valid() and cust_form.is_valid()):
			return self.form_valid(user_form, cust_form)
		else:
			return self.form_invalid(user_form, cust_form)
	def get_success_url(self,**kwargs):
		return('success')

	def form_valid(self,user_form,cust_form):
		self.object = user_form.save()
		self.object.is_staff=True
		self.object.save()
		cust_obj = cust_form.save(commit=False)
		cust_obj.user_data = self.object
		cust_obj.save()
		return redirect('/home/')

	def form_invalid(self,user_form,cust_form):
		return self.render_to_response(self.get_context_data(form1=user_form, form2=cust_form))
	

#views regarding hotels
class HotelList(View):
	template_name="hotellist.html"

	def get(self,request):
		if request.user.is_staff:
			context = {
				'object_list': Hotel.objects.all(),	
			}
			return render(request,self.template_name,context)
		else:
			return redirect('login')

class HotelCreateViewForAdmin(CreateView):
	template_name='hotelcreate.html'
	form_class=HotelForm
	success_url='success'

	def get(self,request):
		if request.user.is_superuser:
			return super(HotelCreateViewForAdmin, self).get(self,request)

#views regarding rooms
class RoomListForAdmin(ListView):
	template_name="roomlist.html"
	model = Room

	def get(self,request):
		if request.user.is_superuser:
			return super(RoomListForAdmin, self).get(self,request)

class RoomCreateView(CreateView):
	template_name='roomcreate.html'
	form_class= RoomCreateForm
	success_url='success'

	def get(self, request):
		if request.user.is_superuser:
			return super(RoomCreateView, self).get(self,request)

class RoomListViewForCustomer(View):
	template_name = 'roomlistforcustomer.html'

	def get(self,request,pk):
		if request.user.is_staff:
			hot_id = pk
			room_list = Room.objects.all().filter(hotel_id=hot_id).filter(status='availiable')
			context = {
				'rooms':room_list,
			}
			return render(request, self.template_name, context)

class RoomBookingView(View):
	template_name = 'bookingroom.html'
	form_class = BookingForm

	def get(self,request,pk):
		if request.user.is_staff:
			ro_id = pk
			ro_list = Room.objects.get(id=ro_id)
			context={
				'selected':ro_list,
				'form': self.form_class,
			}
			return render(request, self.template_name, context)
		else:
			return redirect('/login/')

	def post(self,request,pk):
		ro_id =  pk
		booked_by = request.user.id
		start_date = request.POST.get('start_date')
		end_date = request.POST.get('end_date')
		room_var = Bookings.objects.create(room_id=ro_id,booked_by=booked_by,start_date=start_date,end_date=end_date)
		edit_room = Room.objects.get(id=ro_id)
		edit_room.status = str("unavailiable")
		edit_room.save()
		return redirect('/home/')

#views regarding Cabs
class CabList(ListView):
	template_name="cablist.html"
	model = Cab

class CabCreateViewForAdmin(CreateView):
	template_name='cabcreate.html'
	form_class=CabCreateForm
	success_url='success'

	def get(self,request):
		if request.user.is_superuser:
			return super(CabCreateViewForAdmin, self).get(self,request)

class CabListViewForCustomer(View):
	template_name = 'cablistforcustomer.html'

	def get(self,request):
		if request.user.is_staff:
			cab_list = Cab.objects.all().filter(status='availiable')
			context = {
				'cabs': cab_list,
			}
			return render(request, self.template_name, context)
		else:
			return redirect('login')
	
class CabBookingView(View):
	template_name = 'bookingcab.html'
	form_class = CabBookingForm

	def get(self,request,pk):
		if request.user.is_staff:
			cb_id = pk
			cb_list = Cab.objects.get(id=cb_id)
			context={
				'selected':cb_list,
				'form': self.form_class,
			}
			return render(request, self.template_name, context)
		else:
			return redirect('/login/')

	def post(self,request,pk):
		cb_id =  pk
		booked_by = request.user.id
		start_from = request.POST.get('start_from')
		end_to = request.POST.get('end_to')
		cab_var = CabBookings.objects.create(cab_number=cb_id,booked_by=booked_by,start_from=start_from,end_to=end_to)
		edit_cab = Room.objects.get(id=cb_id)
		edit_cab.status = str("unavailiable")
		edit_cab.save()
		return redirect('/home/')

def comments(request):
    comments_list = Comment.objects.order_by('-created_at')

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():

            ''' Begin reCAPTCHA validation '''
            recaptcha_response = request.POST.get('g-recaptcha-response')
            url = 'https://www.google.com/recaptcha/api/siteverify'
            values = {
                'secret': settings.GOOGLE_RECAPTCHA_SECRET_KEY,
                'response': recaptcha_response
            }
            data = urllib.urlencode(values)
            req = urllib2.Request(url, data)
            response = urllib2.urlopen(req)
            result = json.load(response)
            ''' End reCAPTCHA validation '''

            if result['success']:
                form.save()
                messages.success(request, 'New comment added with success!')
            else:
                messages.error(request, 'Invalid reCAPTCHA. Please try again.')

            return redirect('comments')
    else:
        form = CommentForm()

    return render(request, 'core/comments.html', {'comments': comments_list, 'form': form})

