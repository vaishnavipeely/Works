from django.conf.urls import url,include
from safari import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.contrib.auth import views as auth_views
from safari import views as safari_views

urlpatterns = [
	url(r'^home/$',views.HomeView.as_view(), name="home"),
	url(r'^about/$',views.AboutView.as_view(), name="about"),
	url(r'^contact/$',views.ContactView.as_view(), name="contact"),

	url(r'^list$',views.CustomerList.as_view(), name="list"),
	url(r'^signup$',views.SignUpView.as_view(),name="signup"),

	url(r'^hotel$',views.HotelList.as_view(), name="hotel"),
	url(r'^hotelcreate$',views.HotelCreateViewForAdmin.as_view(),name="hotelcreate"),

	url(r'^roomlist$',views.RoomListForAdmin.as_view(), name="roomlist"),
	url(r'^roomcreate$', views.RoomCreateView.as_view(), name='roomcreate'),
	url(r'^roombooking/(?P<pk>[0-9]+)/$', views.RoomListViewForCustomer.as_view(), name='roombooking'),
	url(r'^confirmation/(?P<pk>[0-9]+)/$', views.RoomBookingView.as_view(), name='confirm_booking'),

	url(r'^cab$',views.CabList.as_view(), name="cab"),
	url(r'^cabcreate$',views.CabCreateViewForAdmin.as_view(),name="cabcreate"),
	url(r'^cabbooking$',views.CabListViewForCustomer.as_view(),name="cabbooking"),
	url(r'^cabconfirmation/(?P<pk>[0-9]+)/$', views.CabBookingView.as_view(), name='confirmcab_booking'),

	url(r'^oauth/', include('social_django.urls', namespace='social')),
	url(r'^login/$', auth_views.login,{'template_name': 'login.html'}, name='login'),
	url(r'^logout/$', auth_views.logout,{'next_page': '/login/'}, name='logout'),	
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
