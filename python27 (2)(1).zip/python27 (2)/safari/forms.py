from django import forms
from safari.models import Hotel,Room,Cab,Register, Bookings,CabBookings
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username','first_name','last_name','email','password1','password2']

class HotelForm(forms.ModelForm):
	class Meta:
		model = Hotel
		exclude = ('',)

class DateInput(forms.DateInput):
	input_type = 'date'

class RoomCreateForm(forms.ModelForm):
	class Meta:
		model = Room
		exclude = ('',)

class CabCreateForm(forms.ModelForm):
	class Meta:
		model = Cab
		exclude = ('',)

class DateInput(forms.DateInput):
	input_type = 'date'

class RegisterForm(forms.ModelForm):
	class Meta:
		model = Register
		exclude = ('user_data',)
		widgets = {
			'dob':DateInput(),
		}

class BookingForm(forms.ModelForm):
	class Meta:
		model = Bookings
		fields = ['start_date','end_date']
		widgets = {
			'start_date': DateInput(),
			'end_date': DateInput(),
		}
class CabBookingForm(forms.ModelForm):
	class Meta:
		model = CabBookings
		fields = ['start_from','end_to']
		
