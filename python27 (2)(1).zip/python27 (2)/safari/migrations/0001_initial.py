# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Cab',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('cab_number', models.IntegerField()),
                ('cab_id', models.IntegerField()),
                ('start_from', models.CharField(max_length=20)),
                ('end_to', models.CharField(max_length=20)),
                ('cab_rent', models.IntegerField()),
                ('status', models.CharField(default='availiable', max_length=10, choices=[('availiable', 'AVAILIABLE'), ('\tunavailiable', 'UNAVAILIABLE')])),
                ('user_id', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Hotel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('hotel_id', models.IntegerField()),
                ('hotelname', models.CharField(max_length=20)),
                ('ph_no', models.IntegerField()),
                ('star_rating', models.IntegerField()),
            ],
        ),
        migrations.CreateModel(
            name='Register',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('pic', models.ImageField(upload_to='media/user/profile_pic')),
                ('dob', models.DateField()),
                ('ph_no', models.IntegerField()),
                ('user_data', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Room',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('room_name', models.CharField(max_length=50)),
                ('from_date', models.DateField()),
                ('to_date', models.DateField()),
                ('room_rent', models.IntegerField()),
                ('status', models.CharField(default='availiable', max_length=10, choices=[('availiable', 'AVAILIABLE'), ('unavailiable', 'UNAVAILIABLE')])),
                ('hotel_id', models.ForeignKey(to='safari.Hotel')),
                ('user_id', models.ForeignKey(blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
        ),
    ]
