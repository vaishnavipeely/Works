# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('safari', '0003_auto_20190119_0717'),
    ]

    operations = [
        migrations.CreateModel(
            name='CabBookings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('cab_number', models.IntegerField()),
                ('booked_by', models.IntegerField()),
                ('booked_date', models.DateTimeField(auto_now=True)),
                ('start_from', models.CharField(max_length=50)),
                ('end_to', models.CharField(max_length=50)),
            ],
        ),
        migrations.RemoveField(
            model_name='cab',
            name='end_to',
        ),
        migrations.RemoveField(
            model_name='cab',
            name='start_from',
        ),
        migrations.RemoveField(
            model_name='cab',
            name='user_id',
        ),
    ]
