# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('safari', '0002_auto_20190119_0623'),
    ]

    operations = [
        migrations.CreateModel(
            name='Bookings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('room_id', models.IntegerField()),
                ('booked_by', models.IntegerField()),
                ('booked_date', models.DateTimeField(auto_now=True)),
                ('start_date', models.DateField()),
                ('end_date', models.DateField()),
            ],
        ),
        migrations.RemoveField(
            model_name='room',
            name='from_date',
        ),
        migrations.RemoveField(
            model_name='room',
            name='to_date',
        ),
        migrations.RemoveField(
            model_name='room',
            name='user_id',
        ),
    ]
