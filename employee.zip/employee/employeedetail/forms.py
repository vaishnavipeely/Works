from django import forms

from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth.models import User

from employeedetail.models import Employee

class UserForm(UserCreationForm):
	class Meta:
		model=User
		fields=['username','first_name','last_name','email','password1','password2']

class EmployeeForm(forms.Form):
	username=forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Enter your user name', 'class': 'form-control'}),required=True)
	first_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Type your first name', 'class': 'form-control'}),required=True)
	last_name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Type your last name', 'class': 'form-control'}),required=True)
	email= forms.EmailField(widget=forms.EmailInput(attrs={'placeholder': 'Type your mail id', 'class': 'form-control'}),required=True)
	dob= forms.