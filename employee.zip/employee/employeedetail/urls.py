from django.conf.urls import  url

from employeedetail.views import CreateEmployee

urlpatterns = [
    # Examples:
    # url(r'^$', 'employee.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    url(r' ', CreateEmployee.as_views(),name='create'),
]