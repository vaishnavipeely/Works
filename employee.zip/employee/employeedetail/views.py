from django.shortcuts import render

from employeedetail.forms import EmployeeForm
# Create your views here.
class CreateEmployee(View):
	template_name='create.html'
	form_class=EmployeeForm

	def get(self,request):
		if request.user.is_superuser:
			context={
			 'form':form
			}
			return render(request,self.template_name,context)
		else:
			return redirect("login")

	def post(self,request):
		form = self.form_class(request.POST,request.FILES)
		if form.is_valid():
			user = User.objects.create_user(username=request.POST.get('username'),password=request.POST.get('pwd1'),
				first_name=request.POST.get('first_name'),last_name=request.POST.get('last_name'),email=request.POST.get('email'))		
		
