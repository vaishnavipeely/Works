from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Employee(models.Model):
	user=models.OneToOneField(User,on_delete=models.CASCADE)
	dob=models.DateTimeField(null=True,blank=True)
	qualification=models.CharField(max_length=15)
	gender=models.CharField(max_length=6)
	dept=models.CharField(max_length=10)
	address=models.TextField()
	doj=models.DateTimeField(null=True,blank=True,auto_now_add=True)

	class Meta:
		verbose_name='Employee'
		verbose_name_plural='Employees'

	def __str__(self):
		return self.user.username
				



				