from django.contrib import admin

from employeedetail.models import Employee
# Register your models here.
admin.site.register(Employee)