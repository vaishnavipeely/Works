from django.conf.urls import url
from django.contrib import admin
from owner.views import ListUser,UserDetail,UpdateDetail

urlpatterns = [
    # Examples:
    # url(r'^$', 'BloodBank.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    url(r'^listuser/',ListUser.as_view(),name='listuser'),
    url(r'^userdetail/(?P<pk>[0-9]+)/$',UserDetail.as_view(),name='userdetail'),
    url(r'^updatedetail/(?P<pk>[0-9]+)/$',UpdateDetail.as_view(),name='updatedetail'),
    
]