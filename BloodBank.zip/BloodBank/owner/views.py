from django.shortcuts import render
from django.views.generic import ListView,DetailView,UpdateView
from django.contrib.auth.models import User
from donor.models import Donor
from donor.forms import DonorForm

# Create your views here.
class ListUser(ListView):
	template_name="userlist.html"
	model=Donor
	context_object_name="user_list"

class UserDetail(DetailView):
	model=Donor
	template_name="userdetail.html"
	context_object_name="detail_list"

class UpdateDetail(UpdateView):
	model=Donor
	template_name="updatedetail.html"
	form_class=DonorForm
	succes_url="success"