from django.db import models

# Create your models here.
class Acceptor(models.Model):
	Name=models.CharField(max_length=20)
	Address=models.TextField()
	Gender=models.CharField(max_length=5)
	Age=models.IntegerField()
	Phone=models.IntegerField()
	Blood_group=models.CharField(max_length=5)
	Email=models.EmailField()
	Required_date=models.DateField(blank=False)
	Hospital=models.CharField(max_length=50)
	Details=models.CharField(max_length=30)
	Status=models.IntegerField()
	create_date=models.DateTimeField(auto_now=True)
	def __str__(self):
		return self.Name
	

