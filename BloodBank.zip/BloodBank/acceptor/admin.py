from django.contrib import admin
from acceptor.models import Acceptor

# Register your models here.
admin.site.register(Acceptor)

