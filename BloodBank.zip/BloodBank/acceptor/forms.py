from django import forms
from acceptor.models import Acceptor

class RequestForm(forms.ModelForm):
	class Meta:
		model=Acceptor
		exclude=('create_date','Status',)

class SearchForm(forms.Form):
	search_query = forms.CharField(max_length=128)
		
