from django.shortcuts import render,redirect
from django.views.generic import CreateView,View
from acceptor.forms import RequestForm
from donor.models import Donor
from django.contrib import messages
from django import forms

# Create your views here.
class BloodRequest(CreateView):
	template_name="request.html"
	form_class=RequestForm
	success_url="Success"

class Search(View):
	template_name='search.html'
	model=Donor
	
	def get(self,request):
		srch=request.GET.get('srh')
		print("Blood:",srch)
		match=Donor.objects.all().filter(Bloodgroup=srch)
		print(match)
		context={
			'match':match,
		}
		return render(request,'search.html',context)

# class SearchList(ListView):
# 	"""docstring for CuVehicleListView"""
# 	template_name='search.html'
# 	def get(self,request):
# 		search_bloodgrp=self.request.GET.get('srh')
# 		print(search_bloodgrp)
# 		queryset = Donor.objects.filter(Bloodgroup__icontains=search_bloodgrp)
# 		return queryset








	
    
    
    
    	
            
            
            
             
            
        
        
			

	
        
        
        
		

	

	
