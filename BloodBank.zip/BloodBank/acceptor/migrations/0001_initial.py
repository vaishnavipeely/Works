# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Acceptor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Name', models.CharField(max_length=20)),
                ('Address', models.TextField()),
                ('Gender', models.CharField(max_length=5)),
                ('Age', models.IntegerField()),
                ('Phone', models.IntegerField()),
                ('Blood_group', models.CharField(max_length=5)),
                ('Email', models.EmailField(max_length=254)),
                ('Required_date', models.DateField()),
                ('Hospital', models.CharField(max_length=50)),
                ('Details', models.CharField(max_length=30)),
                ('create_date', models.DateTimeField(auto_now=True)),
            ],
        ),
    ]
