from django.conf.urls import url
from django.contrib import admin
from acceptor.views import BloodRequest,Search
from acceptor import views

urlpatterns = [
    # Examples:
    # url(r'^$', 'BloodBank.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^bloodrequest/',BloodRequest.as_view(),name='bloodrequest'),
    url(r'^search/',Search.as_view(),name='search'),
    #url(r'^search/',SearchList.as_view(),name='search'),
    
]
