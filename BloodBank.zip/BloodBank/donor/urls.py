from django.conf.urls import url
from django.contrib import admin
from donor.views import RegisterDonor,HomeView,ViewRequest,BloodDonated,ViewDonated
from donor import views

urlpatterns = [
    # Examples:
    # url(r'^$', 'BloodBank.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^registration/',RegisterDonor.as_view(),name='register'),
    url(r'^home/',HomeView.as_view(),name='home'),
    url(r'^about/',views.about_view,name='about'),
    url(r'^viewrequest/',ViewRequest.as_view(),name='viewrequest'),
    url(r'^blooddonated/',BloodDonated.as_view(),name='blooddonated'),
    url(r'^viewdonated/',ViewDonated.as_view(),name='viewdonated'),
]
