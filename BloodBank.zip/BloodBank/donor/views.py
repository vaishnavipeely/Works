from django.shortcuts import render,redirect
from django.views.generic import FormView,TemplateView,ListView,CreateView,View
from django.contrib.auth.models import User
from donor.forms import UserForm,DonorForm,BloodDonatedForm
from donor.models import Donor,ViewDonation
from acceptor.models import Acceptor

from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import auth
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.models import User

# Create your views here.
class HomeView(TemplateView):
    template_name='home.html'
    def get(self,request):
        return render(request,self.template_name)

class ViewRequest(View):
    template_name='listrequest.html'
    def get(self,request):
        user_id=request.user.id
        print("User ID:",user_id)
        user_valid=Donor.objects.all().get(user_data__id=user_id)
        print("Validuser:",user_valid)
        user_bl=Donor.objects.filter(Bloodgroup=user_valid.Bloodgroup)
        print("Blood:",user_bl)
        rec_blood=Acceptor.objects.all().filter(Blood_group=user_bl)
        print(rec_blood)
        context={
            'match':rec_blood,
        }
        return render(request,self.template_name,context)

class BloodDonated(CreateView):
    template_name='blooddonated.html'
    form_class=BloodDonatedForm
    success_url="success"
class ViewDonated(ListView):
    template_name='viewdonated.html'
    model=ViewDonation
    context_object_name='don_list'




def about_view(request):
    return render(request,'about.html')
        
def login(request):
     form =AuthenticationForm()
     if request.user.is_authenticated():
         if request.user.is_superuser:
             return redirect("/adminhome/")# or your url name
         if request.user.is_staff:
             return redirect("/home/")# or your url name


     if request.method == 'POST':
         username = request.POST.get('username')
         password = request.POST.get('password')
         user = auth.authenticate(username=username, password=password)

         if user is not None:
             # correct username and password login the user
             auth.login(request, user)
             if request.user.is_superuser:
                 return redirect("/adminhome/")# or your url name
             if request.user.is_staff:
                 return redirect("/home/")# or your url name

         else:
             messages.error(request, 'Error wrong username/password')
     context = {}
     context['form']=form

     return render(request, 'index.html', context)

@user_passes_test(lambda u: u.is_staff)
def StaffHome(request):
     context = {}
     return render(request, 'home.html', context)

@user_passes_test(lambda u: u.is_superuser)
def AdminHome(request):
     context = {}
     return render(request, 'adminhome.html', context)


class RegisterDonor(FormView):
    template_name = 'register1.html'
    form_class = UserForm
    model = User

    def get(self,request,*args,**kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        donor_form = DonorForm()
        return self.render_to_response(self.get_context_data(form1=user_form,form2=donor_form))

    def post(self,request,*args,**kwargs):
        self.object = None
        form_class = self.get_form_class()
        user_form = self.get_form(form_class)
        donor_form = DonorForm(self.request.POST, self.request.FILES)
        if (user_form.is_valid() and donor_form.is_valid()):
            return self.form_valid(user_form,donor_form)
        else:
            return self.form_invalid(user_form,donor_form)

    def get_success_url(self, **kwargs):
        return ('success')

    def form_valid(self, user_form, donor_form):
        self.object = user_form.save()
        self.object.is_staff=True
        self.object.save()
        donor_obj = donor_form.save(commit=False)
        donor_obj.user_data = self.object
        donor_obj.save()
        return redirect('/home/')

    def form_invalid(self, user_form, donor_form):
        return self.render_to_response(self.get_context_data(form1=user_form,form2=donor_form))


