from django.db import models
from django.contrib.auth.models import User
from acceptor.models import Acceptor

# Create your models here.

class Donor(models.Model):
	user_data = models.OneToOneField(User)
	#FirstName=models.CharField(max_length=20)
	#LastName=models.CharField(max_length=20)
	Image=models.ImageField(upload_to="media/pic/")
	Place=models.CharField(max_length=50)
	Address=models.TextField()
	Pincode = models.IntegerField()
	Age=models.IntegerField()
	Gender=models.CharField(max_length=10)
	Dob=models.DateField()
	Bloodgroup=models.CharField(max_length=5)
	Phone=models.PositiveIntegerField()
	create_date=models.DateTimeField(auto_now=True)
	
	def __str__(self):
		return self.Place

class ViewDonation(models.Model):
	Acceptor_name = models.ForeignKey(Acceptor)
	Blood_group=models.CharField(max_length=5)
	Donator_name=models.CharField(max_length=50)
	Date = models.DateField()
	Units = models.IntegerField()
	




