# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('donor', '0002_viewdonations'),
    ]

    operations = [
        migrations.AddField(
            model_name='viewdonations',
            name='Donator_name',
            field=models.CharField(default=67, max_length=50),
            preserve_default=False,
        ),
    ]
