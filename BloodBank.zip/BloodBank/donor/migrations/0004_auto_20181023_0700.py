# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('donor', '0003_viewdonations_donator_name'),
    ]

    operations = [
        migrations.CreateModel(
            name='ViewDonation',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Acceptor_name', models.CharField(max_length=50)),
                ('Blood_group', models.CharField(max_length=5)),
                ('Donator_name', models.CharField(max_length=50)),
                ('Date', models.DateField()),
                ('Units', models.IntegerField()),
            ],
        ),
        migrations.DeleteModel(
            name='ViewDonations',
        ),
    ]
