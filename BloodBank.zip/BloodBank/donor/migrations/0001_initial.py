# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Donor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Place', models.CharField(max_length=50)),
                ('Address', models.TextField()),
                ('Pincode', models.IntegerField()),
                ('Age', models.IntegerField()),
                ('Gender', models.CharField(max_length=10)),
                ('Dob', models.DateField()),
                ('Bloodgroup', models.CharField(max_length=5)),
                ('Phone', models.PositiveIntegerField()),
                ('create_date', models.DateTimeField(auto_now=True)),
                ('user_data', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]
