from django.contrib import admin
from donor.models import Donor,ViewDonation

# Register your models here.
admin.site.register(Donor)
admin.site.register(ViewDonation)