Install the dependencies through the terminal mentioned in the requirement.txt file using the command given below:

	pip install -r requirement.txt

Install tkinter for python-2 seperately through the terminal for the python project using the command given below:

	sudo apt-get install python-tk


Run the program 'stock_analysis.py' using Python 2

The dataset has been included in the folder and it is named as stock.csv
