import qrcode

from django.db import models
from django.core.urlresolvers import reverse
from django.core.files.uploadedfile import InMemoryUploadedFile


from customer.models import Customer

# Create your models here.

class Category(models.Model):
	category_name=models.CharField(max_length=255)
	category_decription=models.CharField(max_length=255)

	class Meta:
		
		verbose_name="category"
		verbose_name_plural="categorys"

	def __str__(self):
		return self.category_name
	
	
		
class SubCategory(models.Model):
	category=models.ForeignKey(Category)
	subcategory_decription=models.CharField(max_length=255)


	class Meta:
		
		verbose_name="subcategory"
		verbose_name_plural="subcategorys"

	def __str__(self):
		return self.subcategory_decription



SIZE_CHOICES = (
	('sm', 'Small'),
	('md', 'Medium'),
	('lg', 'Large'),
   
)


class Product(models.Model):
	product_name=models.CharField(max_length=50)
	product_decription=models.TextField()
	subcategory=models.ForeignKey(SubCategory)
	size=models.CharField(max_length=3,choices=SIZE_CHOICES)
	image=models.ImageField(upload_to ='media/Images/')
	price=models.IntegerField()
	stock=models.IntegerField()
	qrcode = models.ImageField(upload_to='media/qrcode/{}', blank=True, null=True)
	createdon=models.DateTimeField(auto_now_add=True)
		

	class Meta:
		verbose_name="product"
		verbose_name_plural="products"

	def __str__(self):
		return self.product_name



class Cart(models.Model):
	cust = models.ForeignKey(Customer)
	product = models.ForeignKey(Product)
	count = models.IntegerField()

	def __str__(self):
		return self.cust.user.username

	



