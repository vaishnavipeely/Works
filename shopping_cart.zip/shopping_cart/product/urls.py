from django.conf.urls import  url

from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf import settings

from product.views import CreateproductView,ProductList,ProductDetail,ProductUpdate,CartView





urlpatterns = [
	url(r'^createproduct/',CreateproductView.as_view(),name='createproduct'),
	url(r'^listproduct/',ProductList.as_view(),name="listproduct"),
	url(r'^detail/(?P<pk>[0-9]+)/$',ProductDetail.as_view(),name="detail"),
	
	url(r'^update/(?P<pk>[0-9]+)/$',ProductUpdate.as_view(),name="updateproduct"),
    url(r'^addcart',CartView.as_view(),name='addcart'),




]


urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)  
   