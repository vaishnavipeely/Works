# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('product', '0008_cart'),
    ]

    operations = [
        migrations.AddField(
            model_name='product',
            name='qrcode',
            field=models.ImageField(null=True, upload_to=b'qrcode', blank=True),
        ),
    ]
