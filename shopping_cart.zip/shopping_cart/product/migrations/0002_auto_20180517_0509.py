# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('product', '0001_initial'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='category',
            options={'verbose_name': 'category', 'verbose_name_plural': 'categorys'},
        ),
        migrations.AlterModelOptions(
            name='product',
            options={'verbose_name': 'product', 'verbose_name_plural': 'products'},
        ),
        migrations.AlterModelOptions(
            name='subcategory',
            options={'verbose_name': 'subcategory', 'verbose_name_plural': 'subcategorys'},
        ),
        migrations.RenameField(
            model_name='product',
            old_name='subcategory_name',
            new_name='subcategory',
        ),
        migrations.RenameField(
            model_name='subcategory',
            old_name='subcategory_name',
            new_name='category',
        ),
        migrations.AddField(
            model_name='product',
            name='size',
            field=models.CharField(default='a', max_length=4, choices=[(b'sm', b'Small'), (b'md', b'Medium'), (b'lg', b'Large')]),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='product',
            name='product_name',
            field=models.CharField(max_length=10),
        ),
    ]
