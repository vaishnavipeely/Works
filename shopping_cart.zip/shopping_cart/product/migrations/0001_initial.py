# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('category_name', models.CharField(max_length=255)),
                ('category_decription', models.CharField(max_length=255)),
            ],
        ),
        migrations.CreateModel(
            name='Product',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('product_name', models.CharField(max_length=255)),
                ('product_decription', models.TextField()),
                ('image', models.ImageField(upload_to=b'/home/software/Documents/vaishnavi/Django/shopee/media')),
                ('price', models.IntegerField()),
                ('stock', models.IntegerField()),
            ],
        ),
        migrations.CreateModel(
            name='SubCategory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('subcategory_decription', models.CharField(max_length=255)),
                ('subcategory_name', models.ForeignKey(to='product.Category')),
            ],
        ),
        migrations.AddField(
            model_name='product',
            name='subcategory_name',
            field=models.ForeignKey(to='product.SubCategory'),
        ),
    ]
