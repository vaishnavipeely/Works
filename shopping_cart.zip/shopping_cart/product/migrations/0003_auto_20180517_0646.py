# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('product', '0002_auto_20180517_0509'),
    ]

    operations = [
        migrations.AlterField(
            model_name='product',
            name='size',
            field=models.CharField(max_length=3, choices=[(b'sm', b'Small'), (b'md', b'Medium'), (b'lg', b'Large')]),
        ),
    ]
