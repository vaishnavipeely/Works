import qrcode
from PIL import *

from django.shortcuts import render
from django.shortcuts import redirect
from django.views.generic import CreateView,ListView,DetailView,UpdateView,View


from product.forms import ProductForm
from product.models import Product,SubCategory


# Create your views here.


def generate_qrcode(pdt_id):
	qr = qrcode.QRCode(version=1,error_correction=qrcode.constants.ERROR_CORRECT_L,
			box_size=10,border=4,)

	qr.add_data(pdt_id)
	qr.make(fit=True)

		#filename = 'qrcode-%s.png' % self.id
	img = qr.make_image(fill_color="black",back_color="white")
	return img
	#img.png('test-%d.png' % self.id ,scale=10)
	#img.show() 
		#with open(settings.MEDIA_ROOT + filename, "rb") as reopen:
			#django_file = File(reopen)
			#self.qrcode.save(filename,django_file, save=False)   


class CreateproductView(View):
	template_name="createproduct.html"
	form_class=ProductForm
	success_url="success"
	
	def get(self, request):
		if request.user.is_superuser:
			print("*************************")
			form = self.form_class()

			context = {
				'form': form
			}
			return render(request,self.template_name,context)
		else:
			return redirect("login")

	def post(self, request):
		form = self.form_class(request.POST,request.FILES)
		print("PPPPPPPPPPPPPPPPPPPPPPPPPPPPP")
		if form.is_valid():
			pro,pro1= request.POST.get('subcategory'),request.POST.get('product_name')
			form.save()
			subcat_obj = SubCategory.objects.get(id=request.POST.get('subcategory'))
			pdt_obj = Product.objects.get(subcategory=subcat_obj,product_name=request.POST.get('product_name'))
			qr = generate_qrcode(pdt_obj.id)
			print("RRRRRRRRR",qr)
			pdt_obj.qrcode = qr
			pdt_obj.save()
			context = {
				'form':form,
				'success':"saved successfully"
			}
			return render(request,self.template_name,context)

		else:
			context = {
				'form':form
			}
			return render(request,self.template_name,context)
	

class ProductList(ListView):
	template_name="listproduct.html"
	model = Product
	paginate_by = 3
	context_object_name="pdt_obj"



class ProductDetail(DetailView):

	model = Product
	template_name="productdetail.html"



class ProductUpdate(UpdateView):
	template_name="updateproduct.html"
	form_class=ProductForm
	model = Product
	success_url="success"



class CartView(View):
	def post(self,request):
		print"fghy"
		pdt_id =request.POST.get('product_id')
		cnt = request.POST.get('count')
		print(cnt)
		us = request.user
		print (us)
		user = User.objects.get(username = us)
		prod = Product.objects.get(id = pdt_id)
		usr = Customer.objects.get(usr = user)
		cart = Cart.objects.create(cust = usr ,product = prod ,count = cnt)
		b=cart.save()
		print(b)
		# return redirect('prolist')

		response = 'Success'
		return HttpResponse(json.dumps(response),content_type='json')

	

	



