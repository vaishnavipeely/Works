from django.conf.urls import url
from django.contrib import admin
from django.contrib.auth import views as auth_views
from home import views
from django.contrib.auth.decorators import login_required,permission_required

urlpatterns = [
    url(r'^login/$', views.login, name='login'),
    url(r'^logout/$', auth_views.logout, name='logout'),
    url(r'^home/', views.StaffHome, name='home'),
    url(r'^adminhome/', views.AdminHome, name='adminhome'),
    url(r'^admin/', admin.site.urls),
]
