from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

from django.views.generic import FormView,ListView
from customer.forms import UserForm,CustomerForm
from customer.models import Customer
from django.core.mail import send_mail

# Create your views here.

@login_required
def home(request):
    return render(request,'home.html')


class CreateView(FormView):
	template_name="createform.html"
	form_class= UserForm
	model = User

	def get(self,request,*args, **kwargs):
		self.object = None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		customer_form = CustomerForm()
		return self.render_to_response(
			self.get_context_data(form1=user_form, form2=customer_form))

	def post(self,request,*args,**kwargs):
		self.object = None
		form_class = self.get_form_class()
		user_form = self.get_form(form_class)
		customer_form = CustomerForm(self.request.POST, self.request.FILES)
		if (user_form.is_valid() and customer_form.is_valid()):
			return self.form_valid(user_form, customer_form)
		else:
			return self.form_invalid(user_form, customer_form)


	def get_success_url(self, **kwargs):
		return ('sucess')

	def form_valid(self, user_form, customer_form):
		self.object = user_form.save()
		self.object.is_staff=True
		self.object.save()
		p = customer_form.save(commit=False)
		p.user = self.object
		p.save()
		return super(CreateView, self).form_valid(user_form)


		send_mail(
	    'Success Message',
	    'Successfully Registered.',
	    'vaishnaviks333@gmail.com',
	    ['vaishnaviks333@gmail.com','vaishnavikspeely@gmail.com'],
	    fail_silently=False,
	)


	def form_invalid(self, user_form, customer_form):
		return self.render_to_response(self.get_context_data(form1=user_form,
	   form2=customer_form)) 



class CustomerList(ListView):
	template_name="listcustomer.html"
	model = Customer
	paginate_by = 3
	context_object_name="cust_obj"



