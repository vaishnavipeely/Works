from django import forms

from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

from customer.models import Customer

class UserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['first_name','last_name','email','username','password1','password2']

class CustomerForm(forms.ModelForm):
	class Meta:
		model = Customer
		fields=['contact1','contact2','place','zipcode','address']
			
			
			




