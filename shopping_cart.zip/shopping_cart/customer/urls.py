from django.conf.urls import include, url
from django.contrib.auth import views as auth_views

from customer.views import CreateView,CustomerList
from . import views



urlpatterns = [
    url(r'^$',auth_views.login,{'template_name': 'login.html'},name='login'),
	url(r'^home/$',views.home,name='home'),
	#url(r'^logout/$', auth_views.logout,name='log_out'),
	url(r'^logout/$', auth_views.logout, {'template_name': 'logout.html'}, name='log_out'),
	url(r'^create/',CreateView.as_view(),name='createform'),
	url(r'^list/',CustomerList.as_view(),name="listcustomer.html"),
    url(r'^oauth/', include('social_django.urls', namespace='social')), 

	

    
]
