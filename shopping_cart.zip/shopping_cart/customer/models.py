from django.db import models

from django.contrib.auth.models import User


# Create your models here.
class Customer(models.Model):
	user=models.OneToOneField(User,on_delete=models.CASCADE)
	contact1=models.IntegerField()
	contact2=models.IntegerField() 
	place=models.CharField(max_length=10)
	zipcode=models.IntegerField()
	address=models.TextField()
	createdon=models.DateTimeField(auto_now_add=True)

	class Meta:
		ordering=['user']
		verbose_name="customer"
		verbose_name_plural="customers"

	def __str__(self):
		return self.user.username
	
	
		
			  
		
