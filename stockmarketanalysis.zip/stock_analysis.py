import csv
import numpy as np
from sklearn.svm import SVR
import matplotlib.pyplot as plt
from tkinter import *

root = Tk(className=" STOCK MARKET PREDICTION")
root.geometry("200x200")

label1 = Label(root, text="Read Stock Prices")
label1.grid(row=0,column=2)

dates = []
prices = []

def readingcsv():
        with open('stock.csv', 'r') as csvfile:
                csvFileReader = csv.reader(csvfile)
                next(csvFileReader)     # skipping column names
                for row in csvFileReader:
                        dates.append(int(row[0].split('-')[0]))
                        prices.append(float(row[1]))
        print("Reading complete")
        
btn1 = Button(root,text="Load Data", command=readingcsv)
btn1.grid(row=2,column=2)

label2 = Label(root, text="Predict Price")
label2.grid(row=4,column=2)

entry1 = Entry(root)
entry1.grid(row=7,column=2)

def predictingprice():
        dates1 = np.reshape(dates,(len(dates), 1)) # converting to matrix of n X 1

        svr_rbf = SVR(kernel= 'rbf', C= 1e3, gamma= 0.1) # defining the support vector regression models
        svr_rbf.fit(dates1, prices) # fitting the data points in the models

        plt.scatter(dates1, prices, color= 'black', label= 'Data') # plotting the initial datapoints 
        plt.plot(dates1, svr_rbf.predict(dates1), color= 'red', label= 'RBF model') # plotting the line made by the RBF kernel
        
        year=entry1.get()
        print(type(year))
        y1=np.reshape(year,(1,-1))
        pred =svr_rbf.predict(y1)
        print("Predicted Value="+str(pred))
        

        label3 = Label(root, text=pred)
        label3.grid(row=10,column=2)
        
        plt.xlabel('Date')
        plt.ylabel('Price')
        plt.title('Stock Market Prediction using SVR')
        plt.legend()
        plt.show()
        
        

btn2 = Button(root, text="Predict", command=predictingprice)
btn2.grid(row=8,column=2)

root.mainloop()



