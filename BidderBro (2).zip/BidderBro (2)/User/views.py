# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.

from django.contrib.auth.decorators import user_passes_test,login_required
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render,redirect,get_object_or_404, render_to_response
from django.contrib.auth.models import User
from django.contrib import auth
from django.contrib import messages 

from datetime import date,datetime


from django.views.generic import TemplateView,FormView,View



from User.forms import BidForm,UserEditForm,ContactForm,MainUserForm,UserForm,ProductCatRegForm,ItemForm
from User.models import BidModel,ProductCategoryModel,UserRegisterModel,ContactModel,ProductItem










class AboutWebSite(TemplateView):
	template_name = 'about.html'


class ContactWith(View):
	template_name='contact.html'
	form_class = ContactForm
	def get(self, request):
		form = self.form_class()
		context = {
			'form': form
		}
		return render(request,self.template_name,context)
	
	def post(self, request):
		form = self.form_class(request.POST,request.FILES)
		print('PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP')
		if form.is_valid():
			print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVV')
			form.save()
			context = {
				'form':form,
				'success':"saved successfully"
			}
			return redirect('/login/')
		else:
			print('IIIIIIIIIIIIIIIIIIIIIIIIIIII')
			context = {
				'form':form
			}
			return render(request,self.template_name,context)



class MessageView(FormView):
	template_name='message_view.html'
	def get(self,request):
		if request.user.is_superuser:
			prdobj  = ContactModel.objects.all()
			context={
				'product':prdobj
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')


class UserProfile(FormView):
	template_name='user_profile.html'
	def get(self,request):
		if request.user.is_staff:
			log_user = request.user
			user_obj = User.objects.get(username=log_user)
			custobj  = UserRegisterModel.objects.get(usr=user_obj)
			context={
				'userdict':user_obj,
				'cust':custobj
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')









	







class UserView(FormView):
	template_name = 'view_users.html'
	def get(self,request):
		if request.user.is_superuser:
			usrobj = User.objects.all()
			custobj = UserRegisterModel.objects.all()
			context= {
				'usrobj':usrobj,
				'custobj':custobj
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')
			

class ProductRegistration(View):
	template_name = 'product_register.html'
	form_class = ProductCatRegForm
	def get(self, request):
		if request.user.is_superuser:

			prdobj  = ProductCategoryModel.objects.all()
			form = self.form_class()
			context = {
				'form': form,
				'product':prdobj
			}
			return render(request,self.template_name,context)
		else:
			return redirect("login")





	def post(self, request):
		form = self.form_class(request.POST,request.FILES)
		print('PPPPPPPPPPPPPPPPPPPPP')
		if form.is_valid():
			print('VVVVVVVVVVVVVVVVVV')
			form.save()
			context = {
				'form':form,
				'success':"saved successfully"
			}
			return redirect('/adminhome/')

		else:
			context = {
				'form':form
			}
			return render(request,self.template_name,context)









class ProductUserView(FormView):

	template_name = 'product_user_view.html'
	def get(self,request,pk):
		if request.user.is_staff:
			print('EEEEEEEEEEEEEEEEEEGGGGGGGGGGGGG')
			stud_id = pk
			print(pk)

 			
			user_obj = User.objects.get(id=pk)
			
			custobj  = UserRegisterModel.objects.get(usr=user_obj)
			context={
				'userdict':user_obj,
				'cust':custobj
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')



		# 	stud_obj=UserRegisterModel.objects.get(id=stud_id)
		# 	custobj  = UserRegisterModel.objects.get(usr=user_obj)
			
		# 	form1 = MainUserForm(
		# 		initial={
		# 		'username':user_obj.username,
		# 		'first_name':user_obj.first_name,
		# 		'last_name':user_obj.last_name,
		# 		'email':user_obj.email,
		# 		}
		# 	)
		# 	context = {
		# 		'form1': form1
		# 	}


		# 	form2 = UserEditForm(
		# 		initial={
		# 		'address':stud_obj.address,
		# 		'phone':stud_obj.phone,
		# 		'dob':stud_obj.dob,
		# 		'pincode':stud_obj.pincode,
		# 		'profile_image':stud_obj.profile_image,
		# 		}
		# 	)
		# 	context = {
		# 		'form1': form1,
		# 		'form2': form2,
		# 		'custobj':custobj
		# 	}
			

		# 	return render(request,self.template_name,context)

		# else:
		# 	return redirect('/login/')	






















class EditUserProfile(FormView):

	template_name = 'profile_edit.html'
	form_class = UserForm
	def get(self,request,pk):
		if request.user.is_staff:
			print('EEEEEEEEEEEEEEEEEEGGGGGGGGGGGGG')
			stud_id = pk
			print(pk)

			log_user = request.user
 			user_obj = User.objects.get(username=log_user)

			stud_obj=UserRegisterModel.objects.get(id=stud_id)
			custobj  = UserRegisterModel.objects.get(usr=user_obj)
			
			form1 = MainUserForm(
				initial={
				'username':user_obj.username,
				'first_name':user_obj.first_name,
				'last_name':user_obj.last_name,
				'email':user_obj.email,
				}
			)
			

			form2 = UserEditForm(
				initial={
				'address':stud_obj.address,
				'phone':stud_obj.phone,
				'dob':stud_obj.dob,
				'pincode':stud_obj.pincode,
				'profile_image':stud_obj.profile_image,
				}
			)
			context = {
				'form1': form1,
				'form2': form2,
				'custobj':custobj
			}
			

			return render(request,self.template_name,context)

		else:
			return redirect('/login/')	


	def post(self,request,pk):
		print('PPPPPPPPPPPPPPPPPPPPPPPPPP')
		prd_id= pk
		form = UserEditForm(request.POST,request.FILES)
		edit_obj = UserRegisterModel.objects.get(id=prd_id)
		
		log_user = request.user
 		usr_obj = User.objects.get(username=log_user)

		if form.is_valid():
			print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVV')
			edit_obj.address = str(request.POST.get('address'))
			edit_obj.profile_image = request.FILES.get('profile_image')
			edit_obj.phone = str(request.POST.get('phone'))
			edit_obj.dob = str(request.POST.get('dob'))
			edit_obj.pincode = str(request.POST.get('pincode'))
			
			edit_obj.save()
			


			usr_obj.username = str(request.POST.get('username'))
			usr_obj.email = str(request.POST.get('email'))
			usr_obj.first_name = str(request.POST.get('first_name'))
			usr_obj.last_name = str(request.POST.get('last_name'))
			
			usr_obj.save()

			
			context={
				'form':form
			}
			return redirect('/user_profile/')
		else:
			print('NNNNNNNNNNNNNNNNNNNNNNNNNNNNN')
			print "not cvalid",form.errors
			context = {
			'form':form
			}
			return render(request,self.template_name,context)





def login(request):
	form =AuthenticationForm()
	if request.user.is_authenticated():
		if request.user.is_superuser:
			return redirect("/adminhome/")# or your url name
		if request.user.is_staff:
			return redirect("/userhome/")# or your url name

	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')
		user = auth.authenticate(username=username, password=password)

		if user is not None:
            # correct username and password login the user
			auth.login(request, user)
			if request.user.is_superuser:
				return redirect("/adminhome/")# or your url name
				print('Stafffffffffffffffffffffffffffffff')
			if request.user.is_staff:
				print('Userrrrrrrrrrrrrrrrrrrrrr')
				return redirect("/userhome/")# or your url name
		else:
			#messages.error(request, 'Error wrong username/password')
			messages.error(request, 'Invalid login credentials')
	context = {}
	context['form']=form

	return render(request,'login.html', context)



@user_passes_test(lambda u: u.is_superuser)
def AdminHomePage(request):
	form_class = ProductCatRegForm
	form =form_class()
	context = {
		'form':form
	}
	return render(request, 'admin_home.html',context)





@login_required
@user_passes_test(lambda u: u.is_staff)
def UserHomePage(request):
	if request.user.is_staff:
		log_user = request.user
		user_obj = User.objects.get(username=log_user)
		profile_obj = UserRegisterModel.objects.get(usr=user_obj)
		

		prd_obj  = ProductCategoryModel.objects.all()


		today = date.today()
		print(today)
		# Live Auction
		item_obj1 =  ProductItem.objects.filter(start_date__lte=datetime.today().date(),
                               end_date__gte=datetime.today().date())
                              
		# Upcoming Auction
		item_obj2 = ProductItem.objects.filter(start_date__gt=datetime.today().date())

		# Closed Auction
		item_obj3 = ProductItem.objects.filter(end_date__lte=datetime.today().date())


		
		context={
			'cust':prd_obj,
			'profile_obj':profile_obj,
			'item_obj1': item_obj1,
			'item_obj2': item_obj2,
			'item_obj3': item_obj3
		}
		return render(request,'user_home.html',context)
	else:
		return redirect('/login/')














class UserRegister(FormView):
	template_name='user_register.html'	
	form_class= MainUserForm
	def get(self,request,*args, **kwargs):
		print("ggggggggggggggggggg")
		self.object = None
		form_class = self.get_form_class()
		main_user_form = self.get_form(form_class)
		user_form = UserForm()
		return self.render_to_response(
			self.get_context_data(form1=main_user_form, form2=user_form))
    

# form = self.form_class(request.POST,request.FILES)


	def post(self,request,*args,**kwargs):
		print('TTTTTTTT')
		self.object = None
		form_class = self.get_form_class()
		main_user_form = self.get_form(form_class)
		user_form = UserForm(request.POST,request.FILES) 
		print('PPPPPPPPPPPPPPPPPPPPP')
		if (main_user_form.is_valid() and user_form.is_valid()):
			print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV')
			return self.form_valid(main_user_form, user_form)
		else:
			print('IIIIIIIIIIIIIIIIIIIIIIIIIII')
			return self.form_invalid(main_user_form, user_form)


	def get_success_url(self, **kwargs):
		return ('/login/')

	def form_valid(self, main_user_form, user_form):

		print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV')
		self.object = main_user_form.save()
		self.object.is_staff=True
		self.object.save()
		p = user_form.save(commit=False)
		p.usr = self.object
		p.save()
		return super(UserRegister, self).form_valid(main_user_form)


	def form_invalid(self, main_user_form, user_form):
		return self.render_to_response(self.get_context_data(form1=main_user_form,form2=user_form))









class ItemRegistration(View):
	template_name = 'item_register.html'
	form_class = ItemForm
	def get(self,request):
		if request.user.is_staff:



			log_user = request.user
			user_obj = User.objects.get(username=log_user)
			prd_obj  = ProductItem.objects.filter(usr=user_obj)

			print(log_user)


			form = self.form_class()
			context = {
				'form': form,
				'prd_obj':prd_obj
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')












	def post(self,request):
		form = self.form_class(request.POST,request.FILES)

		if form.is_valid():
			form.save()
			context = {
				'form':form,
				'success':"saved successfully"
			}

			log_user = request.user	

			usr_obj = User.objects.get(username=log_user)

			prd_obj = ProductItem.objects.latest('id')

			print(prd_obj)


			# pubs = Publisher.objects.annotate(num_books=Count('book')).order_by('-num_books')[:5]
			BidModel.objects.create(login_usr=usr_obj,product_details=prd_obj,current_rate=prd_obj.start_price)
		




			return redirect('/userhome/')

		else:
			print('EEEEEEEEEERRRRRRRRRRRRRORRRRRRRRRRRRR')
			context = {
				'form':form
			}
			return render(request,self.template_name,context)
			









# @login_required
# def add_review(request, wine_id):
#     wine = get_object_or_404(Wine, pk=wine_id)
#     form = ReviewForm(request.POST)
#     if form.is_valid():
#         rating = form.cleaned_data['rating']
#         comment = form.cleaned_data['comment']
#         user_name = form.cleaned_data['user_name']
#         user_name = request.user.username
#         review = Review()
#         review.wine = wine
#         review.user_name = user_name
#         review.rating = rating
#         review.comment = comment
#         review.pub_date = datetime.datetime.now()
#         review.save()
#         # Always return an HttpResponseRedirect after successfully dealing
#         # with POST data. This prevents data from being posted twice if a
#         # user hits the Back button.
#         return HttpResponseRedirect(reverse('reviews:wine_detail', args=(wine.id,)))
    
#     return render(request, 'reviews/wine_detail.html', {'wine': wine, 'form': form})



class ProductLive(View):
	template_name='live_product_list.html'
	def get(self,request):
		if request.user.is_staff:
			prdobj =  ProductItem.objects.filter(start_date__lte=datetime.today().date(),
                               end_date__gte=datetime.today().date())
			context={
				'prdobj':prdobj
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')




class ProductUpcomimg(View):
	template_name='upcoming_product_list.html'
	def get(self,request):
		if request.user.is_staff:
			item_obj2 = ProductItem.objects.filter(start_date__gt=datetime.today().date())
			context={
				'prdobj':item_obj2
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')



class ProductClosedList(View):
	template_name='close_product_list.html'
	def get(self,request):
		if request.user.is_staff:
			item_obj3 = ProductItem.objects.filter(end_date__lte=datetime.today().date())
			context={
				'prdobj':item_obj3
			}
			return render(request,self.template_name,context)
		else:
			return redirect('/login/')












class UserDetail(FormView):
	template_name='details_user.html'
	form_class = UserForm
	def get(self,request,pk):
		if request.user.is_superuser:
			print('GGGGGGGGGGGGGGGGGGGGGGGGGG')
			stud_id = pk
			print(pk)

			user_obj = User.objects.get(id=stud_id)
			stud_obj=UserRegisterModel.objects.get(id=stud_id)		
			context = {
				'userdict': user_obj,
				'cust': stud_obj,
			}
			

			return render(request,self.template_name,context)

		else:
			return redirect('/login/')	





class ProductBid(View):
	
	template_name = 'product_bid.html'
	def get(self,request,pk):
		if request.user.is_staff:
			print('GGGGGGGGGGGGGGGGGGGGGGGGGG')
			prd_id = pk
			print(pk)
			


			log_user = request.user
			user_obj = User.objects.get(username=log_user)

			prd_obj = ProductItem.objects.get(id=prd_id)
	

			obj1 = User.objects.get(username=prd_obj.usr)
			


			prd_obj1  = ProductItem.objects.get(id=pk)
						
			bid_obj = BidModel.objects.get(id=pk)


			print(prd_obj1.start_price)


			context = {
				'prd_obj':prd_obj,
				'user_obj':user_obj,
				'obj1':obj1,
				'bid_obj':bid_obj,
				'prd_obj1':prd_obj1

			
			}
				
			return render(request,self.template_name,context)

		else:
			return redirect('/login/')	



	def post(self,request,pk):
	

		prd_id= pk
		form = BidForm(request.POST)
		edit_obj = BidModel.objects.get(id=prd_id)
		
		log_user = request.user
		# user_obj = User.objects.get(username=log_user)
		
		prd_obj = ProductItem.objects.get(id=prd_id)
		# if form.is_valid():
		print('VVVVVVVVVVVVVVVVVVVVVVVVVVVVV')
		edit_obj.login_usr = User.objects.get(username=log_user)
		# edit_obj.product_details = str(request.POST.get('prd_obj'))
		edit_obj.current_rate = str(prd_obj.start_price+prd_obj.bid_price)

		edit_obj.save()
			
		context={
			'form':form
		}
		return redirect('/userhome/')
		# else:
		# 	print('NNNNNNNNNNNNNNNNNNNNNNNNNNNNN')
		# 	print "not cvalid",form.errors
		# 	context = {
		# 	'form':form
		# 	}
		# 	return render(request,'live_product_list.html',context)





	# def post(self, request, *args, **kwargs):
	# 	form = BidForm(request.POST,request.FILES)
	# 	print('PPPPPPPPPPPPPPPPPPPPP')
	# 	if form.is_valid():
	# 		print('VVVVVVVVVVVVVVVVVV')
	# 		form.save()
	# 		context = {
	# 			'form':form,
	# 			'success':"saved successfully"
	# 		}
	# 		return redirect('/adminhome/')

	# 	else:
	# 		context = {
	# 			'form':form
	# 		}
	# 		return render(request,'live_product_list.html',context)



	







# class AddCartView(View):
# 	def post(self,request):






# 		log_id =request.POST.get('login_usr')
# 		product_id = request.POST.get('product_details')
# 		current = request.POST.get('current_rate')


# 		u = request.user

# 		user = User.objects.get(username = u)

# 		pro = Product.objects.get(id = p_id)
# 		usr = Customer.objects.get(usr = user)

# 		bid = BidModel.objects.create(login_usr = usr ,product_details = pro ,current_rate = ct)
# 		bid.save()
# 		# return redirect('prolist')

# 		response = 'Success'
# 		return HttpResponse(json.dumps(response),content_type='json')






class ProductDescription(View):
	
	template_name = 'product_description.html'
	def get(self,request,pk):
		if request.user.is_staff:
			print('GGGGGGGGGGGGGGGGGGGGGGGGGG')
			prd_id = pk
			print(pk)

			prd_obj = ProductItem.objects.get(id=prd_id)		
			context = {
				'prd_obj':prd_obj
			}
				
			return render(request,self.template_name,context)

		else:
			return redirect('/login/')	








