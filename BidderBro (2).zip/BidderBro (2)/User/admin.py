# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.


from User.models import ContactModel,UserRegisterModel,BidModel,ProductCategoryModel,ProductItem

admin.site.register(UserRegisterModel)
admin.site.register(ProductCategoryModel)
admin.site.register(ProductItem)
admin.site.register(BidModel)
admin.site.register(ContactModel)
