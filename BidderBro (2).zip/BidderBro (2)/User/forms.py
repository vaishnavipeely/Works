from django import forms
from django.forms import extras
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.utils import timezone

from django.forms import extras
from User.models import BidModel,ContactModel,UserRegisterModel,ProductCategoryModel,ProductItem



class MainUserForm(UserCreationForm):
	class Meta:
		model= User
		fields=['username','email','first_name','last_name','password1','password2']


class DateInput(forms.DateInput):
	input_type = 'date'




class BidForm(forms.ModelForm):
	class Meta:
		model = BidModel
		exclude = ('creaed_date',)
		
		




class UserForm(forms.ModelForm):
	class Meta:
		model = UserRegisterModel
		exclude =('usr','created_date',)
		widgets = {
			'dob': DateInput(),
        }

class ProductCatRegForm(forms.ModelForm):
	class Meta:
		model = ProductCategoryModel
		exclude=('creaed_date',)

		



class ItemForm(forms.ModelForm):
	class Meta:
		model = ProductItem
		exclude =('created_date',)
		widgets = {
			'start_date': DateInput(),
			'end_date':DateInput(),
		}




class ContactForm(forms.ModelForm):
	class Meta:
		model = ContactModel
		exclude=('created_date',)



class UserEditForm(forms.Form):
	def __init__(self,*args,**kwargs):
		super(UserEditForm,self).__init__(*args,**kwargs)

	address = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Product Name', 'class': 'form-control'}),required=True)
	phone = forms.IntegerField(widget=forms.TextInput(attrs={'placeholder': 'Base value', 'class': 'form-control'}),required=True)
	dob = forms.DateField(required=True)
	pincode = forms.IntegerField(widget=forms.TextInput(attrs={'placeholder': 'Bid value', 'class': 'form-control'}),required=True)
	profile_image = forms.ImageField(required=True)






# class ItemRegistration(forms.Form):
# 	def __init__(self,*args,**kwargs):
# 		super(ItemRegistration,self).__init__(*args,**kwargs)
		
# 	log_user = request.user		
# 	usr = User.objects.get(username=log_user)
# 	phone = forms.IntegerField(widget=forms.TextInput(attrs={'placeholder': 'Base value', 'class': 'form-control'}),required=True)
# 	item_name = forms.CharField(label='Date of Birth',widget=forms.TextInput(attrs={'class': 'form-control datepicker','id':'dob','required':'required','placeholder':'YYYY-MM-DD','readonly':'true'}))
# 	pincode = forms.IntegerField(widget=forms.TextInput(attrs={'placeholder': 'Bid value', 'class': 'form-control'}),required=True)
# 	profile_image = forms.ImageField(required=True)









