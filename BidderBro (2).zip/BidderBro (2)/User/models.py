# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

# Create your models here.




class UserRegisterModel(models.Model):
	usr = models.OneToOneField(User)
	address = models.TextField()
	phone =models.IntegerField()
	dob = models.DateField()
	pincode= models.IntegerField()
	profile_image = models.ImageField(upload_to='media/image',null=True)
	creaed_date = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.usr.first_name+' '+self.usr.last_name


class ProductCategoryModel(models.Model):
	category_name = models.CharField(max_length=100)
	category_pic = models.ImageField(upload_to='media/image',null=True)
	creaed_date = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.category_name

class ProductItem(models.Model):
	usr = models.ForeignKey(User)			
	cat_name = models.ForeignKey(ProductCategoryModel)
	item_name = models.CharField(max_length=50)
	summary = models.TextField(blank=True)
	start_price = models.IntegerField()
	bid_price = models.IntegerField()
	product_image = models.ImageField(upload_to='media/image',null=True)	
	start_date = models.DateField()
	end_date = models.DateField()
	creaed_date = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.item_name



class BidModel(models.Model):
	login_usr = models.ForeignKey(User)
	product_details = models.ForeignKey(ProductItem)
	current_rate = models.IntegerField()		
	creaed_date = models.DateTimeField(auto_now=True)





class ContactModel(models.Model):
	name = models.CharField(max_length=100)
	phone = models.IntegerField()
	email = models.CharField(max_length=100)
	message = models.TextField()
	created_date = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.name