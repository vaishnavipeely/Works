from django.conf.urls import url,include
from django.contrib import admin
from django.contrib.auth import views as auth_views

from User.views import ProductUserView,ProductDescription,ProductClosedList,ProductUpcomimg,ProductBid,UserDetail,ProductLive,UserView,MessageView,ContactWith,ItemRegistration,UserRegister,AboutWebSite,UserProfile,EditUserProfile,ProductRegistration

from User import views


urlpatterns = [
	

 	# Common
 	url(r'^login/$', views.login, name='login'),
 	url(r'^logout/$', auth_views.logout, name='logout'),
 	url(r'about/',AboutWebSite.as_view(),name='about_web'),
 	url(r'contact_with/',ContactWith.as_view(),name='cnt_with'),
 	url(r'user_register/',UserRegister.as_view(),name='usr_reg'),


	

	# admin
 	url(r'^adminhome/', views.AdminHomePage, name='admin_home'),
 	url(r'view_message/',MessageView.as_view(),name='view_msg'),
 	url(r'product_register/',ProductRegistration.as_view(),name='product_reg'),
 	url(r'view_user/',UserView.as_view(),name='view_usr'),
 	url(r'detail_user/(?P<pk>[0-9]+)/$',UserDetail.as_view(),name='detail_usr'),


 	# User
 	url(r'^userhome/', views.UserHomePage, name='user_home'),
 	url(r'item_register/',ItemRegistration.as_view(),name='item_reg'),

 	


 	url(r'user_profile/',UserProfile.as_view(),name='usr_prof'),
 	url(r'profile_edit/(?P<pk>[0-9]+)/$',EditUserProfile.as_view(),name='pro_edit'),
 	url(r'live_product_list/',ProductLive.as_view(),name='product_lis'),
	
	url(r'upcomimg_list/',ProductUpcomimg.as_view(),name='upcomimg_lis'),
	
	url(r'closed_list/',ProductClosedList.as_view(),name='closed_lis'),
	

	url(r'product_bid/(?P<pk>[0-9]+)/$',ProductBid.as_view(),name='product_det'),

	url(r'product_description/(?P<pk>[0-9]+)/$',ProductDescription.as_view(),name='pro_description'),

	url(r'product_user_view/(?P<pk>[0-9]+)/$',ProductUserView.as_view(),name='product_usr_view'),

 	# url(r'item_edit/(?P<pk>[0-9]+)/$',EditItem.as_view(),name='itm_edit'),


 	# url(r'addcart/',AddCartView.as_view(),name='view_cart'),
]