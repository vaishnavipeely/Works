from Tkinter import *
from PIL import Image
from PIL import ImageTk

#image = Image.open("index.jpeg")
#photo = ImageTk.PhotoImage(image)



root = Tk()
root.geometry("500x500")
PILFile = Image.open("index.jpeg")
Image = ImageTk.PhotoImage(PILFile)
ImageLabel = Label(root, image=Image)
#ImageLabel.image = Image
ImageLabel.pack()
root.mainloop()
