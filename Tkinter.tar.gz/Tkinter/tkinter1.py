from tkinter import *
root = Tk(className="My first GUI") # creates root window
# all components of thw window will come here
foo = Label(root,text="Hello World") # add a label to root windows
foo.pack()
root.mainloop() # To keep GUI window running
