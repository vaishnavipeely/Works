from Tkinter import *
# import tkinter

root = Tk()

w = Label(root, text="Hello, world!")
w.pack()

root.mainloop()