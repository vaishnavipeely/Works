from tkinter import *

root = Tk()
root.geometry("500x500")

lbl1 = Label(root,text="Hai GROOVE",bg="cyan",fg="red",bd=10,relief=GROOVE).pack()

lbl2 = Label(root,text="Hai FLAT",bg="cyan",fg="red",bd=10,relief=FLAT).pack()

lbl3 = Label(root,text="Hai SUNKEN",bg="cyan",fg="red",bd=10,relief=SUNKEN).pack()

lbl4 = Label(root,text="Hai SOLID",bg="cyan",fg="red",bd=10,relief=SOLID).pack()

lbl5 = Label(root,text="Hai RAISED",bg="cyan",fg="red",bd=10,relief=RAISED).pack()

lbl6 = Label(root,text="Hai RIDGE",bg="cyan",fg="red",bd=10,relief=RIDGE).pack()

lbl7 = Label(root,text="Hai RIDGE",fg="blue",bd=10,relief=RIDGE,underline=1).pack()

root.mainloop()

