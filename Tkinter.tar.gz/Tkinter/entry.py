from tkinter import *

root = Tk(className="My first GUI") 
root.geometry("500x500")
foo = Label(root,text="Hello World") 
foo.pack()

e = Entry(root).pack()

e.insert(0, "a default value")
s = e.get()
print("value:",s)

lbl2 = Label(root,text=s).pack()
root.mainloop() 
