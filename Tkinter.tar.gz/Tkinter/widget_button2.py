from tkinter import *

root = Tk(className ="My first GUI")
root.geometry("500x500")

svalue = StringVar() # defines the widget state as string


w = Entry(root,textvariable=svalue) # adds a textarea widget
w.pack()

def act():
    print("you entered")
    print('%s' % svalue.get())

foo = Button(root,text="Press Me", command=act,padx=5)
foo.pack()

root.mainloop()
