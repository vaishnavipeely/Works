from tkinter import *
root = Tk()
root.geometry("500x900")
canvas = Canvas(root, width=550, height=820)
canvas.pack()
# png = PhotoImage(file = r'333.png') # Just an example
# canvas.create_image(0, 0, image = png, anchor = "nw")

canvas.create_rectangle(50, 0, 100, 50, fill='red')
# canvas.move(a, 20, 20)

root.mainloop()