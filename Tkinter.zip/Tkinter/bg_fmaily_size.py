from tkinter import*

root = Tk(className="TASK - 1")
root.geometry("500x300")
foo = Label(root,text="Hello World",bg="red",font="times 18")
foo.pack()
foo2 = Label(root,text="Foreground",fg="yellow",font=("Verdana","12"))
foo2.pack()
foo3 = Label(root,text="Background",bg="blue",font=("Helvetica","10"))
foo3.pack()
root.mainloop()
