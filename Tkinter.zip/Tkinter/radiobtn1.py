from tkinter import *

master = Tk()
master.geometry('500x500')
v = IntVar()

rb1 = Radiobutton(master, text="One",  value=1).pack()
rb2 = Radiobutton(master, text="Two",  value=2).pack()

x = v.get()
print(x)
master.mainloop()
