from tkinter import *



root = Tk(className="MY GUI")
root.geometry("300x700")
foo = Label(root,text="Hello World") # add a label to root window
foo.pack()
root.mainloop()

