from tkinter import *

root = Tk(className = "My GUI")
photo = PhotoImage(file="index.jpeg")
w = Label(root, image=photo).pack()
#w.photo = photo
#
root.mainloop()
