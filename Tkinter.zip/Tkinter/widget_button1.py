from tkinter import *


root = Tk(className="Button 1")

root.geometry("500x500")



def action():
	print("HI welcome")

btn1 = Button(root,text="CLICK",command=action)
btn1.pack()
# btn1.flash()
root.mainloop()


