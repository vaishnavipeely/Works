from tkinter import *

master = Tk()

master.geometry("500x500")
var = IntVar()

c = Checkbutton(master, text="Expand", variable=var)
c.pack()
print(var)
master.mainloop()
