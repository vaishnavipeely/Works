from tkinter import *

master = Tk(className="test Frame")
master.geometry('500x500')
lbl1 = Label(text="one").pack()

separator = Frame(height=10, bd=10,relief=SUNKEN)
separator.pack(fill=X, padx=5, pady=5)

lbl2 = Label(text="two").pack()

separator = Frame(height=10, bd=10,relief=FLAT)
separator.pack(fill=X, padx=3, pady=4)

lbl3 = Label(text="three").pack()
master.mainloop()
