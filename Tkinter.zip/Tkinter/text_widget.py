from tkinter import *

root = Tk()

root.geometry("500x500")

txt_obj = Text(root,height=400, width=200)
txt_obj.insert(INSERT, "Hello.....")
#txt_obj.insert("Welcome Hello.....")
txt_obj.insert(END, "Bye Bye.....")
txt_obj.pack()
txt_obj.pack(expand=False, fill=BOTH)
txt_obj.tag_add("here", "1.0", "1.4")
txt_obj.tag_add("start", "1.8", "1.13")
txt_obj.tag_config("here", background="yellow", foreground="blue")
txt_obj.tag_config("start", background="black", foreground="green")


root.mainloop()
