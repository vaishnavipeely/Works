from tkinter import*

root = Tk(className="TASK - 2")
root.geometry("500x500")

longtext = "Ajomol Andrews\nhsjdfhsjkdf\nfsdhfkjsd\n"
foo = Label(root,text=longtext,width=100,bg="pink", anchor=NW,bd=10)
foo.pack()

v = StringVar()
my_label = Label(root, textvariable=v).pack()

v.set("New Text!")

foo3 = Label(root,text="Background",bg="blue",font=("Helvetica","10"))
foo3.pack()

foo4 = Label(root,text="gdfgdfgdg",bg="cyan",bd=5,relief=GROOVE)
foo4.pack()

root.mainloop()
