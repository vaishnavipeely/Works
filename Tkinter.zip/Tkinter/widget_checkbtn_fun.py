from tkinter import *

master = Tk()
master.geometry("500x500")

def __init__(self, master):
    self.var = IntVar()
    c = Checkbutton(master, text="Enable Tab",variable=self.var,command=self.cb)
    c.pack()

def cb(self, event):
    print("variable is", self.var.get())

master.mainloop()
